numero = int(input("Digite um número inteiro positivo: "))
num_digitos = len(str(numero))
print(f"O número {numero} possui {num_digitos} dígitos.")
import numpy as np

# Definindo a matriz B
B = np.array([[3], [2]])

# Imprimindo a matriz B
print("Matriz B:")
print(B)

# Imprimindo manualmente as identificações da matriz B
print("\nIdentificações:")
print("( ) Matriz Inversa")
print("(X) Matriz Linha")
print("( ) Matriz Quadrada")
print("( ) Matriz Transposta")
print("( ) Matriz Coluna")
print("( ) Matriz Nula")
print("( ) Matriz Identidade")
print("( ) Matriz Oposta")

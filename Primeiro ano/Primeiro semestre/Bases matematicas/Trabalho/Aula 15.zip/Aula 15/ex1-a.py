import numpy as np

# Definindo a matriz A
A = np.array([[0, 1]])

# Imprimindo a matriz A
print("Matriz A:")
print(A)

# Imprimindo manualmente as identificações da matriz A
print("\nIdentificações:")
print("( ) Matriz Inversa")
print("(X) Matriz Linha")
print("( ) Matriz Quadrada")
print("( ) Matriz Transposta")
print("( ) Matriz Coluna")
print("( ) Matriz Nula")
print("( ) Matriz Identidade")
print("( ) Matriz Oposta")

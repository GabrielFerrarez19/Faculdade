import numpy as np

# Definindo a matriz C
C = np.array([[0, 0, 0], [0, 0, 0]])

# Imprimindo a matriz C
print("Matriz C:")
print(C)

# Imprimindo manualmente as identificações da matriz C
print("\nIdentificações:")
print("( ) Matriz Inversa")
print("( ) Matriz Linha")
print("( ) Matriz Quadrada")
print("(X) Matriz Transposta")
print("( ) Matriz Coluna")
print("(X) Matriz Nula")
print("( ) Matriz Identidade")
print("( ) Matriz Oposta")

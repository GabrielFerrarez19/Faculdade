import numpy as np

# Definindo a matriz D
D = np.array([[1, 2], [3, 4]])

# Imprimindo a matriz D
print("Matriz D:")
print(D)

# Imprimindo manualmente as identificações da matriz D
print("\nIdentificações:")
print("(X) Matriz Inversa")
print("(X) Matriz Linha")
print("(X) Matriz Quadrada")
print("( ) Matriz Transposta")
print("( ) Matriz Coluna")
print("( ) Matriz Nula")
print("( ) Matriz Identidade")
print("( ) Matriz Oposta")

class Crianca {
    private String nome;

    public Crianca(String nome) {
        this.nome = nome;
    }

    public String getNome() { return nome; }
}
